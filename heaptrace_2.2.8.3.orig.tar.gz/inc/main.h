#ifndef MAIN_H
#define MAIN_H

#include "util.h"
#include "stdint.h"
#include "context.h"

extern HeaptraceContext *FIRST_CTX;
extern uint OPT_ATTACH_PID;
extern uint KEEP_RUNNING;

#endif
